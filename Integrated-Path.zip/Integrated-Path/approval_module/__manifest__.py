# coding: utf-8
{
    'name': 'Approval Customization',
    'category': 'sale',
    'summary': '.',
    'description': """

    """,
    "author": " ",
    'website': ' ',
    'depends': [
        'approvals', 'sale_stock', 'bi_customer_limit'
    ],
    'data': [
        'security/res_groups.xml',
        'views/approval_category_view.xml',
        'views/approval_request_view.xml'
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
