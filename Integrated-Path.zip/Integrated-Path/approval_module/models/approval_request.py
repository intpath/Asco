# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo.exceptions import UserError, Warning
from datetime import datetime


class ApprovalRequest(models.Model):
    _inherit = 'approval.request'

    sale_order_id = fields.Many2one('sale.order', string='Sales Order')
    partner_id = fields.Many2one('res.partner', string="Customer name", store=True, related='sale_order_id.partner_id')
    salesperson_id = fields.Many2one('res.users', string="Salesperson", store=True, related='sale_order_id.user_id')
    customer_balance = fields.Float(string="Customer balance", store=True,
                                    related='sale_order_id.total_receivable')  # Custom field (total_receivable.sale.order)
    blocking_limit = fields.Integer(string="Blocking limit", store=True,
                                  related='partner_id.Blocking_limit')  # Custom field (Blocking_limit.res.partner).
    order_date = fields.Datetime(string="Order Date", store=True, related='sale_order_id.date_order')
    order_total_amount = fields.Float(string="Order total amount", compute="_compute_amount_total",
                                      store=True)  # amount_total
    has_sale_order = fields.Selection(related="category_id.has_sale_order", store=True)
    approval_type = fields.Selection(related="category_id.approval_type", store=True)
    # credit_note
    invoice_id = fields.Many2one('account.move', string='Invoice')
    picking_id = fields.Many2one('stock.picking', 'Transfer')
    credit_note_created = fields.Boolean(string="Credit Note Created ?",
                                         help="This Field will be true if approval invoice have been created "
                                              "to re create need to delete the previous invoice")

    @api.depends('sale_order_id', 'sale_order_id.amount_total')
    def _compute_amount_total(self):
        self.order_total_amount = self.sale_order_id.amount_total


    def update_product_lines(self):
        product_lines = []
        for line in self.sale_order_id.order_line:
            if line.qty_delivered > 0:
                product_lines.append({'order_line_id': line.id,
                                      'product_id': line.product_id.id,
                                      'price_unit': line.price_unit,
                                      'price_subtotal': line.price_subtotal,
                                      'quantity': line.qty_delivered,
                                      'product_uom_id': line.product_id and line.product_id.uom_id and line.product_id.uom_id.id or False,
                                      'description': line.product_id and line.product_id.display_name or line.product_id.name})
        if product_lines:
            self.product_line_ids.unlink()
            self.product_line_ids = [(0, 0, i) for i in product_lines]

    def action_reverse(self):
        if not self.sale_order_id:
            raise Warning("Please select the Sale Order")
        if self.sale_order_id and self.sale_order_id.invoice_ids:
            context = dict(self._context)
            invoice = self.sale_order_id.invoice_ids
            if invoice and len(invoice) == 1:
                if invoice.move_type in ('out_invoice', 'in_invoice'):
                    res = invoice.with_context(context).action_reverse()
                    res['context'] = {'active_model': 'account.move', 'active_ids': invoice.ids}
                    return res
                else:
                    raise Warning("You can only reverse posted moves.")
            else:
                context.update({'default_invoice_id': False, 'invoice': True, 'invoice_ids': invoice.ids})
                view = self.env.ref('approval_module.approval_request_wizard_view_form')
                return {
                    'name': 'Select Invoice to Add Credit Note',
                    'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'res_id': self.id,
                    'res_model': 'approval.request',
                    'views': [(view.id, 'form')],
                    'view_id': view.id,
                    'target': 'new',
                    'context': context,
                }
        else:
            raise Warning("There are no Invoice in the linked Sale order")

    def return_picking(self):
        if not self.sale_order_id:
            raise Warning("Please select the Sale Order")
        picking = self.sale_order_id.picking_ids
        if picking:
            if len(picking) == 1:
                if picking.state == 'done':
                    return self.return_for_picking(picking=picking)
                else:
                    raise Warning("Need to Validate the Picking")
            else:
                view = self.env.ref('approval_module.approval_request_wizard_view_form')
                return {
                    'name': 'Select Invoice to Add Credit Note',
                    'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'res_model': 'approval.request',
                    'views': [(view.id, 'form')],
                    'view_id': view.id,
                    'res_id': self.id,
                    'target': 'new',
                    'context': {'default_picking_id': False, 'picking': True, 'picking_ids': picking.ids},
                }
        else:
            raise Warning("There are no picking in the linked Sale order")


    def perform_action(self):
        if self._context.get('invoice', False):
            if self.invoice_id.state == 'posted' and self.invoice_id.move_type in ('out_invoice', 'in_invoice'):
                res = self.invoice_id.action_reverse()
                res['context'] = {'active_model': 'account.move', 'active_ids': self.invoice_id.ids}
                return res
            else:
                raise Warning("Need to Confirm selected Invoice")

        if self._context.get('picking', False):
            if self.picking_id.state == 'done':
                return self.return_for_picking(picking=self.picking_id)
            else:
                raise Warning("Need to Validate selected Picking")
        return True

    def return_for_picking(self, picking):
        if picking:
            return_id = self.env['stock.return.picking'].sudo().create({'picking_id': picking.id})
            return_id._onchange_picking_id()
            view = self.env.ref('stock.view_stock_return_picking_form')
            # action = self.env["ir.actions.actions"]._for_xml_id("stock.act_stock_return_picking")

            return {
                'name': 'Reserve Transfer',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'stock.return.picking',
                'views': [(view.id, 'form')],
                'view_id': view.id,
                'target': 'new',
                'res_id': return_id.id
                # 'context': {'default_picking_id': False, 'picking': True, 'picking_ids': picking.ids},
            }
        return True

    def account_credit(self):
        if not self.sale_order_id:
            raise UserError("Please select the Sale Order")
        if len(self.sale_order_id.invoice_ids) == 1:
            invoice_id = self.sale_order_id.invoice_ids
            reversal = self.env['account.move.reversal'].create(
                {'journal_id': invoice_id.journal_id.id, 'date': datetime.now(), 'move_ids': invoice_id.ids,
                 'date_mode': 'custom'})
            default_list = reversal._prepare_default_reversal(invoice_id)
            reverse_invoice = invoice_id._reverse_moves([default_list])
            for line in reverse_invoice.invoice_line_ids:
                product_line = self.product_line_ids.filtered(lambda pl: pl.product_id == line.product_id)
                line.with_context(check_move_validity=False).write(
                    {'discount': product_line.discount, 'quantity': product_line.quantity,
                     'price_unit': product_line.price_unit, 'price_subtotal': product_line.price_subtotal})
            self.credit_note_created = True
        elif len(self.sale_order_id.invoice_ids) == 0:
            raise UserError("No Invoice is link with the selected sale order, Please Contact your administrator.")
        elif len(self.sale_order_id.invoice_ids) > 1:
            raise UserError("Multiple Invoice are link with the selected sale order, Please Contact your administrator.")
