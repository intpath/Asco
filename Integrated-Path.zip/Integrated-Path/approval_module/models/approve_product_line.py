# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError, Warning


class ApprovalProductLine(models.Model):
    _inherit = 'approval.product.line'

    price_unit = fields.Float(string="Price Unit", compute="_compute_product_line", store=True, readonly=False)
    price_subtotal = fields.Float(string="Price Subtotal", compute="_compute_line_sub_total", store=True, readonly=False)
    order_line_id = fields.Many2one('sale.order.line', string="Order line")
    product_id = fields.Many2one('product.product', string="Products", compute="_compute_product_line", store=True, readonly=False)
    quantity = fields.Float("Quantity", compute="_compute_product_line", store=True, readonly=False)
    description = fields.Char("Description", compute="_compute_product_line", store=True, readonly=False)
    discount = fields.Float("Discount")
    price_discount_subtotal = fields.Char("Discount Subtotal", compute="_compute_price_discount_subtotal", store=True, readonly=False)

    @api.depends('order_line_id', 'order_line_id.product_id')
    def _compute_product_line(self):
        for record in self:
            record.product_id = record.order_line_id.product_id.id
            record.price_unit = record.order_line_id.price_unit
            record.price_subtotal = record.order_line_id.price_subtotal
            record.quantity = record.order_line_id.product_uom_qty
            record._onchange_product_id()

    @api.depends('quantity', 'price_unit')
    def _compute_line_sub_total(self):
        for record in self:
            record.price_subtotal = record.price_unit * record.quantity

    @api.depends('discount', 'price_subtotal')
    def _compute_price_discount_subtotal(self):
        for record in self:
            # 1000 - (1000 * 75) / 100
            record.price_discount_subtotal = record.price_subtotal - (record.price_subtotal * record.discount) / 100

    def write(self, vals):
        if vals.get('quantity', False) and vals.get('quantity', False) > self.order_line_id.qty_delivered:
            raise UserError(_('Quantity can not be greater the order delivered quantity.'))
        return super(ApprovalProductLine, self).write(vals)

    def unlink(self):
        if self.approval_request_id and self.approval_request_id.sale_order_id and not self.env.is_admin():
            return False
        else:
            return super(ApprovalProductLine, self).unlink()
