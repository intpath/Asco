# -*- coding: utf-8 -*-
{
    'name': "Asco Maintainence",

    'summary': """
        Maintenance Customization module for Asco""",

    'author': "Integrated Path",
    'website': "https://www.int-path.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'maintenance', 'stock', 'analytic', 'hr_timesheet', 'timesheet_grid', 'repair', 'machine_repair_equipment_integration'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/maintenance_equipment_views.xml',
        'views/maintenance_request_views.xml',
        'views/maintenance_team_views.xml',
        'views/project_views.xml',
        'wizard/maintenance_request_create_timesheet_views.xml',
        'data/maintenance_request_timesheet_data.xml',
    ],

}
