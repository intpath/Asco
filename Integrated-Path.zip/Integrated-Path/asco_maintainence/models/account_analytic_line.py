# -*- coding: utf-8 -*-

from odoo import models, fields, api


class AccountAnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    maintenance_request_id = fields.Many2one('maintenance.request', string='Maintenance Request')


    def _compute_project_task_id(self):
        super(AccountAnalyticLine, self)._compute_project_task_id()
        for line in self.filtered(lambda line: line.maintenance_request_id):
            line.task_id = line.maintenance_request_id.task_id

    def _timesheet_preprocess(self, vals):
        maintenance_request_id = vals.get('maintenance_request_id')
        if maintenance_request_id:
            ticket = self.env['maintenance.request'].browse(maintenance_request_id)
            if ticket.project_id:
                vals['project_id'] = ticket.project_id.id
            if ticket.task_id:
                vals['task_id'] = ticket.task_id.id
        vals = super(AccountAnalyticLine, self)._timesheet_preprocess(vals)
        return vals



