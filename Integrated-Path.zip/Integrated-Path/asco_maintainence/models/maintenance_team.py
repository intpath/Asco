# -*- coding: utf-8 -*-

from math import ceil

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class MaintenanceTeam(models.Model):
    _inherit = "maintenance.team"

    use_maintenance_timesheet = fields.Boolean(
        "Timesheet on Maintenance requests",
        help="This required to have project module installed.",
    )

    project_id = fields.Many2one(
        "project.project",
        string="Project",
        ondelete="restrict",
        domain="[('allow_timesheets', '=', True), ('company_id', '=', company_id)]",
        help="Project to which the tickets (and the timesheets) will be linked by default.",
    )
    timesheet_timer = fields.Boolean("Timesheet Timer", default=True)
    display_timesheet_timer = fields.Boolean(compute="_compute_display_timesheet_timer")

    @api.depends("use_maintenance_timesheet")
    def _compute_display_timesheet_timer(self):
        is_uom_hour = self.env.company.timesheet_encode_uom_id == self.env.ref(
            "uom.product_uom_hour"
        )
        for team in self:
            team.display_timesheet_timer = (
                team.use_maintenance_timesheet and is_uom_hour
            )

    @api.depends("use_maintenance_timesheet")
    def _compute_timesheet_timer(self):
        for team in self:
            team.timesheet_timer = team.use_maintenance_timesheet

    def _create_project(self, name, allow_billable, other):
        return self.env["project.project"].create(
            {
                "name": name,
                "type_ids": [
                    (0, 0, {"name": _("In Progress")}),
                    (0, 0, {"name": _("Closed"), "is_closed": True}),
                ],
                "allow_timesheets": True,
                "allow_timesheet_timer": True,
                **other,
            }
        )

    @api.model
    def create(self, vals):
        if vals.get("use_maintenance_timesheet") and not vals.get("project_id"):
            # allow_billable = vals.get('use_helpdesk_sale_timesheet')
            allow_billable = False
            vals["project_id"] = self._create_project(
                vals["name"], allow_billable, {}
            ).id
        return super(MaintenanceTeam, self).create(vals)

    def write(self, vals):
        if (
            "use_maintenance_timesheet" in vals
            and not vals["use_maintenance_timesheet"]
        ):
            vals["project_id"] = False
        result = super(MaintenanceTeam, self).write(vals)
        for team in self.filtered(
            lambda team: team.use_maintenance_timesheet and not team.project_id
        ):
            team.project_id = team._create_project(
                team.name,
                False,
                {"allow_timesheets": True, "allow_timesheet_timer": True},
            )
            self.env["maintenance.request"].search(
                [("maintenance_team_id", "=", team.id), ("project_id", "=", False)]
            ).write({"project_id": team.project_id.id})
        return result

    @api.model
    def _init_data_create_project(self):
        for team in self.search(
            [("use_maintenance_timesheet", "=", True), ("project_id", "=", False)]
        ):
            team.project_id = team._create_project(
                team.name,
                False,
                {"allow_timesheets": True, "allow_timesheet_timer": True},
            )
            self.env["maintenance.request"].search(
                [("maintenance_team_id", "=", team.id), ("project_id", "=", False)]
            ).write({"project_id": team.project_id.id})
