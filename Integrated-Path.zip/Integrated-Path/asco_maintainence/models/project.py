# -*- coding: utf-8 -*-

from odoo import models, fields, api



class Project(models.Model):
    _inherit = 'project.project'

    maintenance_request_ids = fields.One2many('maintenance.request', 'project_id', string='Maintenance Requests')
    maintenance_request_count = fields.Integer('# Requests', compute='_compute_maintenance_request_count')

    maintenance_request = fields.One2many('maintenance.request', 'project_id')

    @api.depends('maintenance_request_ids.project_id')
    def _compute_maintenance_request_count(self):

        result = self.env['maintenance.request'].read_group([
            ('project_id', 'in', self.ids)
        ], ['project_id'], ['project_id'])
        data = {data['project_id'][0]: data['project_id_count'] for data in result}
        for project in self:
            project.maintenance_request_count = data.get(project.id, 0)

    @api.depends('maintenance_request.timesheet_timer')
    def _compute_allow_timesheet_timer(self):
        super(Project, self)._compute_allow_timesheet_timer()

        for project in self:
            project.allow_timesheet_timer = project.allow_timesheet_timer or project.maintenance_request.timesheet_timer
