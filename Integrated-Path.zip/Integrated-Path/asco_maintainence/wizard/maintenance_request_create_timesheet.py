# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class MaintenanceRequestCreateTimesheet(models.TransientModel):
    _name = 'maintenance.request.create.timesheet'
    _description = "Create Timesheet from maintenance request"

    _sql_constraints = [('time_positive', 'CHECK(time_spent > 0)', "The timesheet's time must be positive" )]

    time_spent = fields.Float('Time', digits=(16, 2))
    description = fields.Char('Description')
    maintenance_request_id = fields.Many2one(
        'maintenance.request', "Maintenance Request", required=True,
        default=lambda self: self.env.context.get('active_id', None),
        help="Ticket for which we are creating a sales order",
    )

    def action_generate_timesheet(self):
        values = {
            'task_id': self.maintenance_request_id.task_id.id,
            'project_id': self.maintenance_request_id.project_id.id,
            'date': fields.Datetime.now(),
            'name': self.description,
            'user_id': self.env.uid,
            'unit_amount': self.time_spent,
        }

        timesheet = self.env['account.analytic.line'].create(values)

        self.maintenance_request_id.write({
            'timer_start': False,
            'timer_pause': False
        })
        self.maintenance_request_id.timesheet_ids = [(4, timesheet.id)]
        self.maintenance_request_id.user_timer_id.unlink()
        return timesheet
