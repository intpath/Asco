# -*- coding: utf-8 -*-
{
    'name': "Recruitment Customization",
    'summary': """ Recruitment Customization """,
    'description': """ Recruitment Customization """,
    'author': "AhmedNaseem@IntegratedPath",
    'website': "https://www.int-path.com",
    'category': 'Uncategorized',
    'version': '0.0',
    'depends': ['base', 'hr_recruitment'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/hr_applicant.xml',
    ],

    'license': 'Other proprietary',

}

