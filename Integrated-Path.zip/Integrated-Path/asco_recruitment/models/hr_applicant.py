# -*- coding: utf-8 -*-

from symbol import comparison
from odoo import models, fields, api


class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    interview_date = fields.Datetime(string="Interview Date & Time")
    company_phone = fields.Char(string="Company Phone")
    company_email = fields.Char(string="Company Email")
    
