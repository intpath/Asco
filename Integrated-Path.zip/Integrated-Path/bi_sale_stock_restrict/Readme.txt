1) Version: 14.0.0.1 | Date : 14/06/2022
- Fixed the issue of sale confirmation if product is not available.