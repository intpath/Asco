# -*- coding: utf-8 -*-
{
    'name': "Custom Report Layout",
    'version': '14.0.0.0',
    'summary': 'A module to configure report header and footer',
    'sequence': -100,
    'description': 'A module to configure report header and footer manually from company form',
    'author': "",
    'website': "",
    'category': 'All',
    'license': 'LGPL-3',
    'depends': ['base'],
    'data': [
        'report/base_document_layout.xml',
        'views/views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
