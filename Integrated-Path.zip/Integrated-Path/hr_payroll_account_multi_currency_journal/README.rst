HR Payroll Multi-Currency
You can easily create payslip with multi currency
 Odoo HR Payroll Multi-Currency for create payslip using different currency.

This Extension Allows:
- Apply currency based on Journal assigned in Salary Structure.
- Affect correctly to accounting based on accounting date.
