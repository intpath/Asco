# -*- coding: utf-8 -*-
""" HR Payroll Multi Currency """
from . import models
