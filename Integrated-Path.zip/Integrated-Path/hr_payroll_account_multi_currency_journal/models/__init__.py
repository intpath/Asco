# -*- coding: utf-8 -*-
""" HR Payroll Multi Currency """
from . import hr_payroll_structure
from . import hr_contract
from . import hr_payslip
