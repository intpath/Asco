# -*- coding: utf-8 -*-
{
    "name": "Lab Lease",
    "summary": """ An Odoo Custom Module to manage lab equipment lease contracts. """,
    "description": """ An Odoo Custom Module to manage lab equipment lease contracts. """,
    "author": "AhmedNaseem@IntegratedPath",
    "website": "https://www.int-path.com",
    "category": "Uncategorized",
    "version": "15.0",
    "depends": ["base", "stock", "sale_management"],
    "data": [
        "security/res_groups.xml",
        "security/ir.model.access.csv",
        "views/views.xml",
        "views/templates.xml",
        "views/lease_contract_views.xml",
        "views/lease_product_views.xml",
        "views/portal_layout_template.xml",
    ],
    "license": "Other proprietary",
}
