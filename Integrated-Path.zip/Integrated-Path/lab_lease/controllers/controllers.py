# -*- coding: utf-8 -*-
import datetime
import json

from odoo import http
from odoo.exceptions import UserError
from odoo.http import request

MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
]
TABLE_HEADERS = ["Contract Number", "Contract Start Date"] + MONTHS

CONTEXT = {}


class SalesTargetReport(http.Controller):
    @http.route(
        "/sales_target_report/<int:page>", auth="user", website=True, methods=["GET"]
    )
    def list(self, page, **post):
        CUSTOMERS_PER_PAGE = 8
        CONTEXT[http.request.env.user.id] = {}
        OFFSET = (page) * CUSTOMERS_PER_PAGE
        if post.get("year"):
            CONTEXT[http.request.env.user.id]["year"] = int(post.get("year"))
        else:
            CONTEXT[http.request.env.user.id]["year"] = datetime.datetime.now().year
        year = CONTEXT[http.request.env.user.id].get("year")

        total_customers_objects = (
            http.request.env["res.partner"]
            .search([("contract_ids", "!=", False)])
            .filtered(
                lambda partner: partner.contract_ids.filtered(
                    lambda contract: contract.date_start.year == year
                )
            )
        )
        total_customers = int(len(total_customers_objects) / CUSTOMERS_PER_PAGE) + 1

        contracts_list = http.request.env["lease.contract"].search(
            [("state", "=", "active")]
        )
        contracts_per_customer = self.sort_contracts_per_customers(
            contracts_list, int(year), CUSTOMERS_PER_PAGE, OFFSET
        )
        return http.request.render(
            "lab_lease.listing",
            {
                "root": "/sales_target_report/",
                "table_headers": TABLE_HEADERS,
                "contracts_per_customers": contracts_per_customer,
                "year": year,
                "next_year": int(year) + 1,
                "previous_year": int(year) - 1,
                "total_customers": range(total_customers),
                "current_page": page,
            },
        )

    @http.route(
        "/sales_target_report/details/",
        auth="user",
        website=True,
        methods=["POST", "GET"],
    )
    def details(self, **post):
        headers = {"Content-Type": "application/json"}
        year, month, contract = (
            post.get("year"),
            post.get("month"),
            post.get("contract"),
        )
        if contract and year and month:
            contract = http.request.env["lease.contract"].search(
                [("number", "=", contract)]
            )
            consumables_ids = self.get_consumables(contract)
            order_lines = self.get_detailed_lines_per_month_year(
                contract, int(year), int(month), consumables_ids
            )
            return http.request.render(
                "lab_lease.sale_order_line_list",
                {
                    "root": "/sales_target_report/details",
                    "order_lines": order_lines,
                    "contract": contract,
                    "year": year,
                    "month": month,
                    "total": round(
                        sum([line.price_subtotal for line in order_lines]), 2
                    ),
                },
            )

    def get_detailed_lines_per_month_year(self, contract, year, month, consumables_ids):
        if consumables_ids:
            sale_order_lines = (
                http.request.env["sale.order.line"]
                .search(
                    [
                        ("product_id", "in", consumables_ids),
                        ("order_id.partner_id", "=", contract.customer_id.id),
                        ("order_id.state", "in", ["sale", "done"]),
                    ]
                )
                .filtered(
                    lambda sol: sol.order_id.date_order.year == year
                    and sol.order_id.date_order.month == month
                )
            )
            return sale_order_lines
        else:
            return []

    def sort_contracts_per_customers(
        self, contracts_list, year, CUSTOMERS_PER_PAGE, offset
    ):
        contracts_per_customer = {}
        month_index = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        customers_with_contracts = http.request.env["res.partner"].search(
            [("contract_ids", "!=", False)], limit=CUSTOMERS_PER_PAGE, offset=offset
        )

        for customer in customers_with_contracts:
            for contract in customer.contract_ids:
                if contract.date_start.year == year:
                    if not contracts_per_customer.get(contract.customer_id.name, False):
                        contracts_per_customer[contract.customer_id.name] = {
                            "contracts": [],
                            "customer_id": str(contract.customer_id.id),
                        }
                    consumables_ids = self.get_consumables(contract)
                    contracts_per_customer[contract.customer_id.name][
                        "contracts"
                    ].append(
                        {
                            "number": contract.number,
                            "date": contract.date_start,
                            "monthly_target": contract.monthly_target,
                            "months": [
                                self.get_total_sales_per_month_year(
                                    contract, year, month, consumables_ids
                                )
                                for month in month_index
                            ],
                        }
                    )

        return contracts_per_customer

    def get_total_sales_per_month_year(self, contract, year, month, consumables_ids):
        if consumables_ids:
            sale_order_lines_sum = sum(
                http.request.env["sale.order.line"]
                .search(
                    [
                        ("product_id", "in", consumables_ids),
                        ("order_id.partner_id", "=", contract.customer_id.id),
                        ("order_id.state", "in", ["sale", "done"]),
                    ]
                )
                .filtered(
                    lambda sol: sol.order_id.date_order.year == year
                    and sol.order_id.date_order.month == month
                )
                .mapped("price_total")
            )
            return [month, round(sale_order_lines_sum, 2)]
        else:
            return [0, 0]

    def get_consumables(self, contract):
        consumables_ids = []
        for contract_line in contract.contract_line_ids:
            consumables_ids += contract_line.product_id.consumables_ids.ids
        return consumables_ids
