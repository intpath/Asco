# -*- coding: utf-8 -*-

from . import lease_contract, lease_product, res_partner
