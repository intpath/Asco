# -*- coding: utf-8 -*-

from typing import Dict

from odoo import fields, models
from odoo.exceptions import UserError


class LeaseContract(models.Model):
    _name = "lease.contract"
    _description = "Lease Contract"
    _rec_name = "number"
    _sql_constraints = [
        (
            "number_uniq",
            "unique (number)",
            "The number of the contract must be unique !",
        ),
    ]

    contract_type = fields.Selection(
        [("lease", "Lease"), ("cash", "Cash")],
        string="Contract Type",
        required=True,
        default="lease",
    )

    target_amount = fields.Monetary(
        string="Annual Target Amount", required=True, currency_field="currency_id"
    )

    sales_person_id = fields.Many2one(
        "res.users", string="Salesperson", related="customer_id.user_id"
    )

    monthly_target = fields.Monetary(
        string="Monthly Target", compute="_compute_monthly_target"
    )

    currency_id = fields.Many2one(
        "res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.user.company_id.currency_id,
    )

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("active", "Active"),
            ("close", "Closed"),
        ],
        string="State",
        default="draft",
        copy=True,
    )
    number = fields.Char(string="Number", required=True)
    offer_number = fields.Char(string="Offer Number")
    customer_id = fields.Many2one("res.partner", string="Customer", required=True)
    date_start = fields.Date(string="Start Date", required=True)
    date_end = fields.Date(string="End Date", required=True)
    contract_line_ids = fields.One2many(
        "lease.contract.line", "contract_id", string="Contract Lines"
    )
    company_id = fields.Many2one(
        "res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.user.company_id,
    )

    def action_reset_draft(self):
        for contract in self:
            if not self.env["sale.order"].search(
                [("lease_contract_id", "=", contract.id)]
            ):
                contract.state = "draft"
            else:
                raise UserError(
                    "Cannot reset contract to draft state as it has performance lines or sale orders"
                )

    def action_close(self):
        for contract in self:
            if contract.state != "active":
                raise UserError("Contract must be in active state to be closed")
            contract.state = "close"

    def set_active(self):
        # ensure contract is in draft state
        for contract in self:
            if contract.state != "draft":
                raise UserError("Contract must be in draft state to be activated")
            if contract.contract_line_ids:
                contract.state = "active"

            else:
                raise UserError("Contract must have at least one contract line")

    def _compute_monthly_target(self):
        for contract in self:
            contract.monthly_target = contract.target_amount / 12


class LeaseContractLine(models.Model):
    _name = "lease.contract.line"
    _description = "Lease Contract Line"
    _rec_name = "product_id"

    product_id = fields.Many2one("lease.product", string="Product", required=True)
    related_product_id = fields.Many2one(
        "product.product",
        string="Product",
        related="product_id.related_product_id",
        readonly=True,
    )

    sn_id = fields.Many2one(
        "stock.production.lot",
        string="Serial Number",
        required=True,
        domain="[('product_id', '=', related_product_id)]",
    )

    contract_id = fields.Many2one("lease.contract", string="Contract", required=True)
    price = fields.Float(
        string="Price", related="product_id.related_product_id.lst_price"
    )
    contract_status = fields.Selection(
        [
            ("draft", "Draft"),
            ("active", "Active"),
            ("close", "Closed"),
        ],
        string="Parent Status",
        related="contract_id.state",
        readonly=True,
    )

    def action_create_sale_order(self, context: Dict = "") -> Dict:

        return {
            "type": "ir.actions.act_window",
            "name": "Sale Order",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "sale.order",
            "target": "new",
            "context": {
                "default_lease_product_id": self.product_id.id,
                "default_lease_contract_id": self.contract_id.id,
                "default_partner_id": self.contract_id.customer_id.id,
            },
        }
