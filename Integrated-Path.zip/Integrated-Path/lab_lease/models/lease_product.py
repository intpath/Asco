# -*- coding: utf-8 -*-

from odoo import api, fields, models


class LeaseProduct(models.Model):
    _name = "lease.product"
    _description = "Lease Product"
    _rec_name = "name"

    name = fields.Char(string="Name", required=True)

    related_product_id = fields.Many2one(
        "product.product", string="Product", required=True
    )

    consumables_ids = fields.Many2many(
        comodel_name="product.product",
        relation="lease_product_product_product_rel",
        column1="lease_product_id",
        column2="product_product_id",
        string="Consumables",
    )

    def action_redirect_sale_orders(self):
        return {
            "name": "Sale Orders",
            "type": "ir.actions.act_window",
            "view_mode": "tree,form",
            "res_model": "sale.order",
            "domain": [("lease_product_id", "=", self.id)],
        }
