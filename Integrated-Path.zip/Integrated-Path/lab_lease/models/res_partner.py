# -*- coding: utf-8 -*-


from odoo import fields, models


class ResPartner(models.Model):
    _inherit = "res.partner"

    contract_ids = fields.One2many("lease.contract", "customer_id", string="Contracts")
