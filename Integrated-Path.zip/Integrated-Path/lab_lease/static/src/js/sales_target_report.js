console.log("Extended Assets Loaded Successfully")

let customers = document.querySelectorAll('.customer');
customers.forEach((customer)=>{
    customer.addEventListener('click',()=>{
        let customerContracts = document.querySelectorAll(`.contract_${customer.id.split('_')[1]}`)
        customerContracts.forEach((customerContract)=>{
            if(customerContract.style.display == 'table-row'){
                customerContract.style.display = "none";
            }else{
                customerContract.style.display = 'table-row';
            }
        })
    })
})





