# authorize_net

API installation path:
=========================

Please refer below link for download API:
https://github.com/AuthorizeNet/sdk-python

Before start odoo server need to install authorizenet python package.
Installation Command : pip3 install authorizenet

Note:
========================
1. Payment Method electronic not getting from base
