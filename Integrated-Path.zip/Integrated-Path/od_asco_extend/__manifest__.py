# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Od Asco Extend',
    'version': '16.0.1.10',
    'category': 'Accounting',
    'summary': '',
    'author': '',
    'website': '',
    'description': """
    """,
    'depends': [
          'account','stock', 'sale', 'fleet'
    ],
    'data': [
        'report/customer_payment.xml',
        'report/report_invoice.xml',
        'report/delivery_slip.xml',
        'views/template.xml',
        'views/sale_order.xml',
        'views/account_payment.xml',
        'views/stock_picking.xml',
    ],
    'demo': [],
    'images': [],
    'license': 'LGPL-3',
    'installable': True,
    'application': False,
    'auto_install': False,
}
