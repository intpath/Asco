# -*- coding: utf-8 -*-

from odoo import models, fields, api


class AccountMove(models.Model):
    _inherit = "account.move"

    def get_expiry_date(self, id):
        if id:
            res = self.env['stock.production.lot'].search([('id', '=', int(id))])
            if res and res.name and res.expiration_date:
                expiry_date = res.expiration_date.date()
                return expiry_date
        else:
            return ""

    def get_invoice_cash_credit(self):
        if self.invoice_origin:
            res = self.env['sale.order'].search([('name', '=', self.invoice_origin)], limit=1)
            if res:
                if res.invoice_type == 'cash':
                    return 'cash'
                elif res.invoice_type == 'credit':
                    return 'credit'
        else:
            return False

    def get_customer_balance(self):
        amount = 0
        user_type_id = self.env['account.account.type'].search([("id", 'in',
                                                                 [self.env.ref('account.data_account_type_payable').id,
                                                                 self.env.ref("account.data_account_type_receivable").id])])

        if user_type_id:
            res = self.env['account.move.line'].sudo().search([('parent_state', '=', 'posted'),
                                                        ('account_id.reconcile', '=', True),
                                                        ('account_id.user_type_id', 'in',
                                                         user_type_id.ids),
                                                        ('partner_id', '=', self.partner_id.id)])
            if res:
                amount = sum([i.balance for i in res])
        return amount


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    analytic_tag_ids = fields.Many2many("account.analytic.tag", string="Analytic Tags", compute="_compute_analytic_tag",
                                        store=True)
    receive_by = fields.Char(string="Received By")
    written_amount = fields.Char(string="Written Payment Amount")

    @api.depends("move_id")
    def _compute_analytic_tag(self):
        for rec in self:
            if rec.move_id and rec.move_id.line_ids and rec.move_id.line_ids.analytic_tag_ids:
                rec.analytic_tag_ids = [(6, 0, rec.move_id.line_ids.analytic_tag_ids.ids)]
            else:
                rec.analytic_tag_ids = False


    def get_customer_previous_balance(self):
        amount = 0
        user_type_id = self.env['account.account.type'].sudo().search([("id", 'in',
                                                                 [self.env.ref('account.data_account_type_payable').id,
                                                                  self.env.ref(
                                                                      "account.data_account_type_receivable").id])])

        if user_type_id:
            res = self.env['account.move.line'].sudo().search([('parent_state', '=', 'posted'),
                                                               ('account_id.reconcile', '=', True),
                                                               ('account_id.user_type_id', 'in',
                                                                user_type_id.ids),
                                                               ('partner_id', '=', self.partner_id.id)])

            if res:
                amount = sum([i.balance for i in res])
                if self.payment_type == 'outbound':
                    amount = amount - self.amount
                if self.payment_type == 'inbound':
                    amount = amount + self.amount
        return amount

    def get_customer_current_balance(self):
        amount = 0
        user_type_id = self.env['account.account.type'].sudo().search([("id", 'in',
                                                                 [self.env.ref('account.data_account_type_payable').id,
                                                                  self.env.ref(
                                                                      "account.data_account_type_receivable").id])])

        if user_type_id:
            res = self.env['account.move.line'].sudo().search([('parent_state', '=', 'posted'),
                                                               ('account_id.reconcile', '=', True),
                                                               ('account_id.user_type_id', 'in',
                                                                user_type_id.ids),
                                                               ('partner_id', '=', self.partner_id.id)])
            if res:
                amount = sum([i.balance for i in res])
        return amount
