# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"

    invoice_type = fields.Selection([('cash', 'Cash'), ('credit', 'Credit')], string="Invoice Type")
