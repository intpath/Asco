# -*- coding: utf-8 -*-

from odoo import models, fields, api


class StockPicking(models.Model):
    _inherit = "stock.picking"

    vehicle_id = fields.Many2one("fleet.vehicle", string='Vehicle')
    driver_id = fields.Many2one("res.partner", related="vehicle_id.driver_id", string="Driver")
    model_id = fields.Many2one("fleet.vehicle.model", related="vehicle_id.model_id", string="Model")
    license_plate = fields.Char(related="vehicle_id.license_plate", string="License Plate")





    def get_driver_name(self):
        vehicle = False
        if self.move_lines:
            state = self.env['fleet.vehicle.state'].search([('name', '=', 'Registered')], limit=1)
            if state:
                for partner in self.move_lines:
                    print("/xc/zxc/cx/czx/czxc/zxc/", partner.partner_id)
                vehicle = self.env['fleet.vehicle'].search([('driver_id', '=', self.move_lines[0].partner_id.id),
                                                            ('state_id', '=', state.id)], limit=1)
        return vehicle