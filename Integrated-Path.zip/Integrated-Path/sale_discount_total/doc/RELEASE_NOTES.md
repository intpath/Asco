## Module <inventory_barcode_scanning>

#### 08.10.2020
#### Version 14.0.1.0.0
#### ADD
Initial commit for Sale Discount On Total Amount

#### 01.04.2021
#### Version 14.0.1.1.0
#### FIX
discount roundoff



