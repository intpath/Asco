# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.
{
    "name": "Leave Attachment",
    "author": "Softhealer Technologies",
    "license": "OPL-1",
    "website": "https://www.softhealer.com",
    "support": "support@softhealer.com",
    "category": "human resources",
    "summary": "Leave Request Attachment, Leave Management,Attach Leave Documents,Required Leave Document,Leave Request Add Files, Attach Docs With Leave, Add Leave Attachment,leave Document,leave employee attachment,leave request employee attachment Odoo",
    "description": """This module used to attach a document with the leave request. This module provides an attachment field in a leave request, if you want to make it required so just tick 'Attachment' in 'leave type' then attachment required for that particular leave.
 Leave Request Attachment Odoo, Leave Management Odoo""",
    "version": "14.0.3",
    "depends": ["hr_holidays", ],
    "application": True,
    "data": [
            "views/sh_leave_type.xml",
    ],
    "images": ["static/description/background.png", ],
    "live_test_url": "https://youtu.be/j0nPGXM7VQs",
    "auto_install": False,
    "installable": True,
    "price": 15,
    "currency": "EUR"
}
