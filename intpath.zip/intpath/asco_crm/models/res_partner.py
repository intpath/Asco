# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError


class ResPartner(models.Model):
    _inherit = "res.partner"

    CONTACT_TYPE = [
        ('company', 'شركة'),
        ('student', 'طالب'),
        ('hospital', 'مستشفى'),
        ('laboratory', 'مختبر'),
    ]

    DELIVERY_TYPE = [
        ('government ', 'Government'),
        ('private', 'Private'),
    ]

    contact_type = fields.Selection(CONTACT_TYPE, required=True)
    sector = fields.Selection(
        DELIVERY_TYPE, required=True, string="Sector Type")

    type = fields.Selection(
        [('contact', 'Contact'),
         ('owner ', 'Owner '),
         ('invoice', 'Invoice Address'),
         ('delivery', 'Delivery Address'),
         ('other', 'Other Address'),
         ("private", "Private Address"),
         ], string='Address Type',
        default='contact',
        help="Invoice & Delivery addresses are used in sales orders. Private addresses are only visible by authorized users.")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not (vals.get('street') or vals.get('city') or vals.get('state_id') or vals.get('country_id') or vals.get('sector') or vals.get('contact_type') or vals.get('phone') or vals.get('image_1920')):
                raise UserError('You Must Fill The Required fields')
            else:
                pass
        return super(ResPartner, self).create(vals_list)

