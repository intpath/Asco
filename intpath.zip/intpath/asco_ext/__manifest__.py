# -*- coding: utf-8 -*-
{
    'name': "Asco Extention",
    'summary': """This module has a lot of customizations for Asco.""",
    'description': """
        This module will add the following:
            1-Sequence in line items for Sales and Purchase models .
            2-Redirect Line items to its relevant product lots tree view.
            3-Notes per line item (Sales and Purchase).
            4-Group Inventory Records by Product Category.
            5-Customer to be added in product moves list view.
    """,
    'author': "AliFaleh@IntegratedPath",
    'website': "http://www.int-path.com",
    'category': 'Customization',
    'version': '14.0',
    'depends': ['base', 'sale_management'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/sale_order.xml',
        'views/stock_quant.xml',
        'views/stock_move_line.xml',
    ],
}
