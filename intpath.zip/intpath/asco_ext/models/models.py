# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.addons.web.controllers.main import clean_action
from odoo.exceptions import UserError

class SaleOrderLineExt(models.Model):
    _inherit = 'sale.order.line'

    # seq = fields.Integer(compute="_compute_seq")
    notes = fields.Text(string="Notes")

    def _compute_seq(self):
        index = 1
        for rec in self:
            rec.seq = index
            index += 1

    def get_lots(self):
        action = self.env.ref('stock.action_production_lot_form').read()[0]
        action['domain'] = [['product_id', '=', self.product_id.id]]
        return action


class SaleOrderLineExt(models.Model):
    _inherit = 'stock.quant'

    product_category = fields.Many2one('product.category', string="Product Category", related='product_id.categ_id', store=True)



class StockMoveLine(models.Model):
    _inherit = "stock.move.line"

    customer = fields.Many2one('res.partner', string="Customer", related='move_id.partner_id', store=True)



