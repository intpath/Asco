# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"
    
    DELIVERY_TYPE = [
        ('government ', 'Government'),
        ('private', 'Private'),
    ]
    DELIVERY_METHOD = [
        ('by_rep ', 'By Rep'),
        ('by_fleet', 'By Fleet'),
        ('pickup', 'PickUp'),
        ('by_external_company', 'By External Company'),
    ]
    
    
    backup_partner_id = fields.Many2one(
        'res.partner', string='Backup Partner')
    backup_partner_phone = fields.Char(
        related="backup_partner_id.phone", string='Backup Partner Phone')
    is_manual_invoice = fields.Boolean("Manual Invoice ?")
    is_quality_check = fields.Boolean("Quality Check ?")
    # packing = fields.Char("Packing")

    delivery_type = fields.Selection(
        string="Sector Type", related='partner_id.sector', required=False)
    delivery_method = fields.Selection(DELIVERY_METHOD, string="Delivery Method")


class StockQuant(models.Model):
    _inherit = "stock.quant"

    product_categ_id = fields.Many2one(related="product_id.categ_id", store=True)
