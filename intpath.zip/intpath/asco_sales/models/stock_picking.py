# -*- coding: utf-8 -*-

from odoo import models, fields, api


class StockPicking(models.Model):
    _inherit = "stock.picking"
    
    
    backup_partner_id = fields.Many2one(
        related="sale_id.backup_partner_id", readonly=True)
    backup_partner_phone = fields.Char(
        related="sale_id.backup_partner_id.phone", string='Backup Partner Phone', readonly=True)
    is_manual_invoice = fields.Boolean(
        related="sale_id.is_manual_invoice", readonly=True)
    is_quality_check = fields.Boolean(
        related="sale_id.is_quality_check", readonly=True)
    packing = fields.Char("Packing")

    delivery_type = fields.Selection(
        related="sale_id.delivery_type", readonly=True)
    delivery_method = fields.Selection(
        related="sale_id.delivery_method", readonly=True)
