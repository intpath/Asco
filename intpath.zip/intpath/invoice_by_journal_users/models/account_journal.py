# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    custom_user_ids = fields.Many2many(
        'res.users', 
        string='Allow Access Users',
        copy=True,
    )

    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        if self.env['res.users'].has_group('invoice_by_journal_users.group_limited_acces_journal_user'):
            #args = [('custom_user_ids', 'in', self.env.user.id)] - 25jan2021
            args += [('custom_user_ids', 'in', self.env.user.ids)]
            return super(AccountJournal, self)._search(args, offset, limit, order, count, access_rights_uid)
        else:
            return super(AccountJournal, self)._search(args, offset, limit, order, count, access_rights_uid)
