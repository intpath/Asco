# -*- coding: utf-8 -*-
# Part of Probuse Consulting Service Pvt. Ltd.
# See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class MaintenanceEquipment(models.Model):
    _inherit = "maintenance.equipment"

    custom_partner_id = fields.Many2one('res.partner', string='Customer')
    custom_repair_count = fields.Integer(compute='_compute_repair_counter', string="Machine Repair")
    email = fields.Char("Email", compute='_compute_partner_info')
    phone = fields.Char("Phone", compute='_compute_partner_info')

    def _compute_repair_counter(self):
        for record in self: 
            record.custom_repair_count = self.env['machine.repair.support'].search_count([
                ('custom_equipment_id', 'in', record.ids)
                ])
    
    @api.onchange('custom_partner_id')    
    def _compute_partner_info(self):
        for record in self: 
            record.email = record.custom_partner_id.email
            record.phone = record.custom_partner_id.phone

    #@api.multi
    def action_machine_repair(self):
        for record in self:
            action = self.env.ref('machine_repair_management.action_machine_repair_support').read()[0]
            action['domain'] = [('custom_equipment_id', 'in', record.ids)]
            return action

    @api.model
    def name_search(self, name='', args=None, operator="ilike", limit=100):
        args = args or []
        domain = args + ['|', ('name', operator, name), ('serial_no', operator, name)]
        return super(MaintenanceEquipment, self).search(domain, limit=limit).name_get()
