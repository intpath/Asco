# -*- coding: utf-8 -*-

from . import analytic_account_line
from . import machine_repair_support
from . import support_team
from . import ticket_task
from . import product
from . import repair_types
from . import nature_of_service
from . import repair_estimation_lines
from . import sale
from . import res_partner
