# -*- coding: utf-8 -*-

from odoo import models, fields, api

class AnalyticLine(models.Model):
    _inherit = "account.analytic.line"
    
    repair_request_id = fields.Many2one('machine.repair.support', string="Repair Request")
