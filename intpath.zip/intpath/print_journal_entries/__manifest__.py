# -*- coding: utf-8 -*-
{
    'name': "Print Journal Entries",
    'summary': """This module allow user to print journal entry in pdf format.""",
    'description': """This module allow user to print journal entry in pdf format.""",
    'author': "Probuse Consulting Service Pvt. Ltd.",
    'website': "www.probuse.com",
    'category': 'Account',
    'version': '0.1',
    'depends': ['base', 'account'],
    'data': [
        'views/report_reg.xml',
        'views/journal_entires_view.xml',
        'views/external_layout.xml',
        'views/header.xml',
        'views/res_company_views.xml'
    ],
}
