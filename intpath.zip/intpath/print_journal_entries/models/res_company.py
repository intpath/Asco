# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError

class ResCompanyExt(models.Model):
    _inherit="res.company"

    arabic_name = fields.Char(string="Company Arabic Name")
    long_name = fields.Char(string="Detailed Name",translate=True)