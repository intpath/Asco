# report_stock_inventory

### A Module for MDI developed by Inegrated Path
