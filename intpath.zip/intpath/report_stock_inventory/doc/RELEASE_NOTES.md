## Module <report_stock_inventory>

#### 3.05.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Inventory Report PDF and XLSX

#### 17.10.2019
#### Version 12.0.2.0.1
##### FIX
- depends 'report_xlsx' removed
