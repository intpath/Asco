# -*- coding: utf-8 -*-
from . import stock_report_pdf
