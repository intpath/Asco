# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo.exceptions import UserError


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    picking_id = fields.Many2one("stock.picking", string="Transfer", readonly=True)
    returned_picking_id = fields.Many2one(
        "stock.picking", string="Return Transfer", readonly=True
    )
    return_picking_lines = fields.One2many(
        "approval.request.return.picking.line", "request_id", "Moves"
    )
    is_return_approval = fields.Boolean(
        "Return Approval?", compute="_compute_is_return_approval"
    )
    location_id = fields.Many2one("stock.location", "Return Location", readonly=True)

    @api.depends("category_id")
    def _compute_is_return_approval(self):
        for record in self:
            record.is_return_approval = (
                True if record.category_id.approval_type == "return" else False
            )

    def action_approve(self, approver=None):
        res = super(ApprovalRequest, self).action_approve(approver)
        if self.is_return_approval:
            self.picking_id.is_return_approved = True
            return self.create_return()
        else:
            pass
        return res

    def create_return(self):
        for record in self:
            product_return_moves = []
            for line in record.return_picking_lines:
                product_return_moves.append(
                    (
                        0,
                        0,
                        {
                            "product_id": line.product_id.id,
                            "quantity": line.quantity,
                        },
                    )
                )
            stock_return_picking = self.env["stock.return.picking"].create(
                {
                    "picking_id": record.picking_id.id,
                    "location_id": record.location_id.id,
                    "product_return_moves": product_return_moves,
                }
            )
            stock_return_picking._onchange_picking_id()
            # raise UserError(str(stock_return_picking.create_returns()))
            res = stock_return_picking.create_returns()
            record.returned_picking_id = res["res_id"]
            return res
