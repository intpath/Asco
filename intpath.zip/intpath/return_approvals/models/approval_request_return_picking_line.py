# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ApprovalRequestReturnPickingLine(models.Model):
    _name = "approval.request.return.picking.line"
    _rec_name = 'product_id'
    _description = 'Approval Request Return Picking Line'

    product_id = fields.Many2one(
        'product.product', string="Product", readonly=True)
    quantity = fields.Float(
        "Quantity", digits='Product Unit of Measure', readonly=True)
    request_id = fields.Many2one('approval.request', string="Request")
