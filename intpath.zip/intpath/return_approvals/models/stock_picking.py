# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class StockPicking(models.Model):
    _inherit = "stock.picking"

    is_return_approved = fields.Boolean("Return Approved?", readonly=True, copy=False)


class StockReturnPicking(models.TransientModel):
    _inherit = "stock.return.picking"

    is_return_approved = fields.Boolean(related="picking_id.is_return_approved")

    def create_return_approval(self):
        for record in self:
            new_approval = record.env["approval.request"].create(
                {
                    "name": f"{record.picking_id.name} Return approval request",
                    "request_owner_id": record.env.user.id,
                    "picking_id": record.picking_id.id,
                    "location_id": record.location_id.id,
                    "category_id": self.env.ref(
                        "return_approvals.approval_category_data_return_approval"
                    ).id,
                }
            )

            for return_line in record.product_return_moves:
                new_approval.write(
                    {
                        "return_picking_lines": [
                            (
                                0,
                                0,
                                {
                                    "product_id": return_line.product_id.id,
                                    "quantity": return_line.quantity,
                                },
                            )
                        ],
                    }
                )

            return {
                "name": new_approval.name,
                "type": "ir.actions.act_window",
                "res_model": "approval.request",
                "views": [[False, "form"]],
                "res_id": new_approval.id,
                "target": "current",
            }
