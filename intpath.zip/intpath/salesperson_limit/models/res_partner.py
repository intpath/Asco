from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = "res.partner"

    user_id = fields.Many2one(default=lambda self : self.env.user.id)

    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        if self.env['res.users'].has_group('salesperson_limit.salesperson_own_contacts'):
            #args = [('custom_user_ids', 'in', self.env.user.id)] - 25jan2021
            args += ['|', ('user_id', '=', self.env.user.id),
                     ('id', '=', self.env.user.partner_id.id)]
            return super(ResPartner, self)._search(args, offset, limit, order, count, access_rights_uid)
        else:
            return super(ResPartner, self)._search(args, offset, limit, order, count, access_rights_uid)
