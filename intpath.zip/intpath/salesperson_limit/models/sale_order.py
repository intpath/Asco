# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"
    pass
    # partner_id = fields.Many2one(
    #     'res.partner', string='Customer', readonly=True,
    #     states={'draft': [('readonly', False)], 'sent': [
    #         ('readonly', False)]},
    #     required=True, change_default=True, index=True, tracking=1,
    #     domain="['|', ('company_id', '=', False), ('company_id', '=', company_id), ('user_id', '=', user_id)]",)
